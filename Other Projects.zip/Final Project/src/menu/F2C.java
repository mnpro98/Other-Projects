/**

*

*/

package menu;

import java.io.BufferedReader;

import java.io.InputStreamReader;

import java.io.IOException;

/**
 *
 * 
 * 
 * This class displays degrees celsius.
 *
 * 
 * 
 * @author Mauricio Na�ez and Olivia G�mez
 * 
 * @since 24/11/2015
 * 
 * @version 1.0
 *
 * 
 * 
 */

public class F2C {

	// Method 1: Converts fahrenheit into celsius.

	public static void main(String[] args) throws IOException {

		BufferedReader stdIn = new BufferedReader(new InputStreamReader(System.in));

		boolean keepRunning = true;

		while (keepRunning = true) {
			System.out.print("Enter temperature in farenheit: ");
			try {

				double F = Double.parseDouble(stdIn.readLine());

				double C = (F - 32) / 1.8;

				System.out.print(C + " degrees celsius\n");

				keepRunning = false;

				break;

			} catch (Exception e) {

				System.out.println("Try again!");

			}

		}

	}

}