/**
 * 
 */
package menu;

import java.io.IOException;
import java.util.Scanner;

/**
 * This class is the program selection.
 * 
 * @author Mauricio Na�ez & Olivia Gomez
 * @version 1.0
 * @since 20/11/2015
 *
 */
public class MainMenu {

	public static Scanner input = new Scanner(System.in);

	/**
	 * @param args
	 * @throws IOException
	 */
	// Method main: Asks the user to pick a type of program.
	public static void main(String[] args) throws IOException {
		int value = 0;
		boolean exit = false;
		while (!exit) {
			System.out.println("Pick an option: ");
			System.out.println("1.\tIO Programs ");
			System.out.println("2.\tControl Structures");
			System.out.println("3.\tRepetition Structures");
			System.out.println("4.\tMethods & Classes");
			System.out.println("5.\tUser defined Methods");
			System.out.println("9.\tEXIT");

			try {
				value = input.nextInt();
			} catch (Exception e) {
				System.out.println("Incorrect value try again: ");
				input.nextLine();
				value = 0;
			}

			switch (value) {
			case 1:
				System.out.println("Pick an option: ");
				System.out.println("1.\tOperations ");
				System.out.println("2.\tCelsius to Farenheit");
				System.out.println("3.\tFarenheit to Celsius");
				System.out.println("4.\tCurrency");
				try {
					int newValue = input.nextInt();
					ioMethods(newValue);
					break;
				} catch (Exception e) {
					System.out.print("Error, restarting..");
					break;
				}
			case 2:
				System.out.println("Pick an option: ");
				System.out.println("1.\tFever");
				System.out.println("2.\tPosNeg");
				System.out.println("3.\tShirts");
				System.out.println("4.\tBonusWage");
				System.out.println("5.\tOrderChecker");
				System.out.println("6.\tDelicatessen");
				System.out.println("7.\tTirePressure");
				System.out.println("8.\tMoreTirePressure");
				System.out.println("9.\tExtraPoints");
				try {
					int Value2 = input.nextInt();
					cStructures(Value2);
					break;
				} catch (Exception e) {
					System.out.println("Error, restarting...");
					break;
				}
			case 3:
				System.out.println("Pick an option: ");
				System.out.println("1.\tChristmas Tree (Asterisks)");
				try {
					int Value3 = input.nextInt();
					rStructures(Value3);
					break;
				} catch (Exception e) {
					System.out.println("Error, restarting...");
					break;
				}
			case 4:
				System.out.println("Pick an option: ");
				System.out.println("1.\tTempConverter");
				System.out.println("2.\tEmployees");
				try {
					int Value4 = input.nextInt();
					methodsClasses(Value4);
					break;
				} catch (Exception e) {
					System.out.println("Error, restarting...");
				}
			case 5:

				System.out.println("No options avalilable at this time.");
				break;

			case 9:
				System.out.println("Bye bye");
				exit = true;
				break;
			default:
				System.out.println("Invalid option, try again");
				value = 0;
			}
		}

	}

	// Inside the IO programs option.
	public static void ioMethods(int aValue) throws IOException {
		switch (aValue) {
		case 1:
			Operations.main(null);
			break;
		case 2:
			C2F.main(null);
			break;
		case 3:
			F2C.main(null);
			break;
		case 4:
			Currency.main(null);
			break;
		}

	}

	// Inside the Control Structures menu.
	public static void cStructures(int aValue) throws IOException {
		switch (aValue) {
		case 1:
			Fever.main(null);
			break;
		case 2:
			PosNeg.main(null);
			break;
		case 3:
			Shirts.main(null);
			break;
		case 4:
			BonusWage.main(null);
			break;
		case 5:
			OrderChecker.main(null);
			break;
		case 6:
			Delicatessen.main(null);
			break;
		case 7:
			TirePressure.main(null);
			break;
		case 8:
			MoreTirePressure.main(null);
			break;
		case 9:
			Hundread.main(null);
			break;
		}

	}

	// Inside the Repetition Structures menu.
	public static void rStructures(int aValue) throws IOException {
		switch (aValue) {
		case 1:
			BytePrint.main(null);
			break;
		}

	}

	// Inside the Methods menu.
	public static void methodsClasses(int aValue) throws IOException {
		switch (aValue) {
		case 1:
			TempConverter.main(null);
			break;
		case 2:
			Employees.main(null);
		}

	}
}
