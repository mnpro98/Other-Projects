package menu;

import java.io.IOException;

import java.util.Scanner;

/**
 *
 * 
 * 
 * This class determines the amount of pesos per dollar.
 *
 * 
 * 
 * @author Olivia G�mez
 * 
 * @since 24/11/2015
 * 
 * @version 1.0
 *
 * 
 * 
 */

public class Currency {

	public static Scanner sc = new Scanner(System.in);

	// Method 1: Prompts user for rate and maount of dollars and converts
	// mexican pesos into dollars

	public static void main(String[] args) throws IOException {

		boolean keepRunning = true;

		while (keepRunning = true) {

			try {

				System.out.println("Please insert pesos per dollar");

				int rate = sc.nextInt();

				System.out.println("Please insert an amount of dollars");

				int usd = sc.nextInt();

				int ppd = rate * usd;

				System.out.println("The amount of pesos per " + usd + " is: " + ppd);

				keepRunning = false;

				break;

			} catch (Exception e) {

				System.out.println("Error, restarting...");

				sc.nextLine();

			}

		}

	}
}