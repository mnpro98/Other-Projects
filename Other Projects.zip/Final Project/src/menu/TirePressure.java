package menu;

/**

*

* This class determines if inflation in car tires is ok.

*

* @author Mauricio Na�ez and Olivia G�mez

* @version 1.00

* @since 11/17/2015

*/

import java.util.Scanner;

public class TirePressure {

	public static Scanner sc = new Scanner(System.in);

	// Method 1: Prompts the user for values and determines whether the
	// inflation is ok or not.

	public static void main(String[] args) {

		boolean keepRunning = true;

		while (keepRunning = true) {

			try {

				System.out.println("Right Front pressure");

				double rfp = sc.nextDouble();

				System.out.println("Left Front pressure");

				double lfp = sc.nextDouble();

				System.out.println("Right Rear pressure");

				double rrp = sc.nextDouble();

				System.out.println("Left Rear pressure");

				double lrp = sc.nextDouble();

				if (rfp == lfp && rrp == lrp) {

					System.out.println("The inflation is OK.");

				} else {

					System.out.println("The inflation is NOT ok.");

				}

				keepRunning = false;

				break;

			} catch (Exception e) {

				System.out.println("Error, restarting...");

				sc.nextLine();

			}

		}

	}
}