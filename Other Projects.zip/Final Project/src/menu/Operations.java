package menu;

import java.io.IOException;

import java.io.BufferedReader;

import java.io.InputStreamReader;

/**
 *
 * 
 * 
 * This class displays the multiplication, addition, subtraction and division of
 * two numbers.
 *
 * 
 * 
 * @author Mauricio Na�ez and Olivia G�mez
 * 
 * @since 24/11/2015
 * 
 * @version 1.0
 *
 * 
 * 
 */

public class Operations {

	// Method 1: Prompts user for 2 values & calculates their sum, subtraction,
	// division, and multiplication.

	public static void main(String[] args) throws IOException {

		BufferedReader stdIn = new BufferedReader(new InputStreamReader(System.in));

		boolean keepRunning = true;

		while (keepRunning = true) {
			System.out.println("Instert a number ");
			try {

				double number1 = Integer.parseInt(stdIn.readLine());

				System.out.println("Instert another number ");

				double number2 = Integer.parseInt(stdIn.readLine());

				double sum = number1 + number2;

				double subtraction = number1 - number2;

				double multiplication = number1 * number2;

				double division = number1 / number2;

				System.out.println("Sum = " + sum);

				System.out.println("Subtraction = " + subtraction);

				System.out.println("Multiplication = " + multiplication);

				System.out.println("Division = " + division);

				keepRunning = false;

				break;

			} catch (Exception e) {

				System.out.println("Incorrect input, restarting...");

			}

		}

	}
}