/**
 * 
 */
package menu;

/**

*

* This class checks if the order is correct or not.

*

* @author Mauricio

* @version 1.00

* @since 11/17/2015

*/

import java.util.Scanner;

public class OrderChecker {

	public static Scanner sc = new Scanner(System.in);

	// Method 1: Prompts user for values and determines whether or not the order
	// is right.

	public static void main(String[] args) {

		boolean keepRunning = true;

		while (keepRunning = true) {

			try {

				System.out.println("Enter the number of bolts");

				int bolts = sc.nextInt();

				System.out.println("Enter the number of nuts");

				int nuts = sc.nextInt();

				System.out.println("Enter the number of washers");

				int washers = sc.nextInt();

				double totalbolts = bolts * 0.5;

				double totalnuts = nuts * 0.3;

				double totalwashers = washers * 0.1;

				if (totalbolts >= totalnuts && totalnuts >= totalwashers) {

					System.out.println("The Order is OK.");

					System.out.println("Total cost: " + (totalbolts + totalnuts + totalwashers) + " dollars");

				} else {

					System.out.println("Check the order.");

					System.out.println("Total amount will not be calculated.");

				}

				keepRunning = false;

				break;

			} catch (Exception e) {

				System.out.println("Error, restarting...");

				sc.nextLine();

			}

		}

	}
}