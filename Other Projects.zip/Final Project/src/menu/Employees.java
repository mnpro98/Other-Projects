package menu;

import java.util.Scanner;

import java.io.IOException;

/**
 * 
 * @author Mauricio Na�ez
 * 
 * @since 24/11/2015
 * 
 * @version 1.0
 * 
 */

public class Employees {

	public static Scanner sc = new Scanner(System.in);

	// Method 1: Prompts user for information about the applicant, determines if
	// employee is hired,

	// displays all information about the applicant and asks user if they want
	// to exit the program.

	public static void main(String[] args) throws IOException {

		boolean keepRunning = true;

		while (keepRunning = true) {

			int score1 = 0;

			int score2 = 0;

			int age = 0;

			double Av = 0;

			boolean exit = false;

			while (!exit) {

				String approval = null;

				String name = null;

				try {

					System.out.println("Enter your name");

					name = sc.nextLine();

					System.out.println("Enter your age");

					age = sc.nextInt();

					System.out.println("Enter the score of your first test");

					score1 = sc.nextInt();

					System.out.println("Enter the score of your second test");

					score2 = sc.nextInt();

					Av = (score1 + score2) / 2;

					if (age < 40) {

						Av += 2;

					} else {

						Av += 5;

					}

					if (Av >= 75) {

						approval = "HIRED";

					} else {

						approval = "REJECTED";

					}

					System.out.println("*************************************");

					System.out.println("EMPLOYEE NAME: " + name);

					System.out.println("AGE: " + age);

					System.out.println("SCORES: " + score1 + " " + score2);

					System.out.println("CURVED AVERAGE: " + Av + "\t" + approval);

					System.out.println("*************************************");

					sc.nextLine();

				} catch (Exception e) {

					System.out.println("If you wish to exit, enter *");

					sc.nextLine();

					String quitString = sc.nextLine();

					try {

						if (quitString.contains("*")) {

							exit = true;

							break;

						}

						keepRunning = false;

						break;

					} catch (Exception b) {

						main(quitString);

						sc.nextLine();

					}

				}

			}
		}

	}

	// Method 2: Calculates curved Average.

	public static void curvedAvg(String[] args) throws IOException {

		boolean keepRunning = true;

		while (keepRunning = true) {

			int age = 0;

			try {

				keepRunning = false;

				break;

			} catch (Exception e) {

				quit(age);

				sc.nextLine();

			}
		}

	}

	// Method 3: Asks user if they want to exit.

	public static void quit(int score1) throws IOException {

		boolean keepRunning = true;

		while (keepRunning = true) {

			System.out.println("If you wish to exit, enter *");

			sc.nextLine();

			String quitString = sc.nextLine();

			try {

				if (quitString == "*") {

					main(quitString);

				}

				keepRunning = false;

				break;

			} catch (Exception e) {

				main(quitString);

				sc.nextLine();

			}
		}

	}

	// Method 4: Displays "Later!"

	private static void main(String quitString) {

		System.out.println("Later!");

	}

}