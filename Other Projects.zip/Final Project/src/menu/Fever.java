package menu;

import java.util.Scanner;

/**
 *
 * 
 * 
 * This class displays if the user has a fever or not.
 *
 * 
 * 
 * @author Mauricio
 * 
 * @version 1.00
 * 
 * @since 11/17/2015
 * 
 */

public class Fever {

	public static Scanner sc = new Scanner(System.in);

	// Method 1: Prompts user for temperature and determines if he/she has a
	// fever.

	public static void main(String[] args) {

		boolean keepRunning = true;

		while (keepRunning = true) {

			try {

				System.out.println("Enter your temperature in celsius ");

				double temp = sc.nextDouble();

				if (temp > 39) {

					System.out.println("Sorry, you have fever.");

				} else {

					System.out.println("You have a normal temperature.");

				}

				keepRunning = false;

				break;

			} catch (Exception e) {

				System.out.println("Error, restarting...");

				sc.nextLine();

			}

		}

	}
}