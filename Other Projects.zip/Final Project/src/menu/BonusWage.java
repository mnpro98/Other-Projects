package menu;

import java.util.Scanner;

/**
 * 
 * This class determines the wage of every worker.
 *
 * 
 * 
 * @author Mauricio
 * 
 * @version 1.00
 * 
 * @since 11/17/2015
 * 
 */

public class BonusWage {

	public static Scanner sc = new Scanner(System.in);

	// Method 1: Determines the Wage of the Workers

	public static void main(String[] args) {

		boolean keepRunning = true;

		while (keepRunning = true) {

			System.out.println("How many hours did you work?");

			try {

				double hours = sc.nextDouble();

				System.out.println("How much do you get paid per hour?");

				double rate = sc.nextDouble();

				if (hours > 30) {

					System.out.println("Congratulations! You won " + (hours * rate * 1.5) + "$");

				} else {

					System.out.println("You won " + (hours * rate) + "$");

				}

				keepRunning = false;

				break;

			} catch (Exception e) {

				System.out.println("Error, restarting...");

				sc.nextLine();

			}

		}

	}
}