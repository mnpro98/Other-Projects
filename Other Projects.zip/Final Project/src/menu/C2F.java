package menu;

import java.util.Scanner;

/**
 *
 * 
 * 
 * This class determines temperature.
 *
 * 
 * 
 * @author Mauricio Na�ez and Olivia G�mez
 * 
 * @version 1.0
 * 
 * @since 24/11/2015
 * 
 */

public class C2F {

	public static Scanner sc = new Scanner(System.in);

	// Method 1: Converts celsius into fahrenheit.

	public static void main(String[] args) {

		boolean keepRunning = true;

		while (keepRunning = true) {

			try {

				System.out.println("Enter temperature in celsius: ");

				double C = sc.nextDouble();

				double F = C * 1.8 + 32;

				System.out.println(F + " degrees farenheit");

				keepRunning = false;

				break;

			} catch (Exception e) {

				System.out.println("Error, restarting...");

				sc.nextLine();

			}

		}

	}
}