package menu;

import java.util.Scanner;

/**
 *
 * 
 * 
 * This class displays if a number is negative or positive
 *
 * 
 * 
 * @author Mauricio
 * 
 * @version 1.00
 * 
 * @since 11/17/2015
 * 
 */

public class PosNeg {

	public static Scanner sc = new Scanner(System.in);

	// Method 1: Prompts user for value and determines whether it's negative or
	// positive.

	public static void main(String[] args) {

		boolean keepRunning = true;

		while (keepRunning = true) {

			try {

				System.out.println("Input a number ");

				double number = sc.nextDouble();

				if (number < 0) {

					System.out.println("That is a negative number.");

				} else {

					System.out.println("That is a positive number.");

				}

				keepRunning = false;

				break;

			} catch (Exception e) {

				System.out.println("Error, restarting...");

				sc.nextLine();

			}

		}

	}
}