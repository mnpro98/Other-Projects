package menu;

import java.util.Scanner;

/**
 *
 * 
 * 
 * This class displays what is the total amount to pay
 *
 * 
 * 
 * @author Mauricio
 * 
 * @version 1.00
 * 
 * @since 11/17/2015
 * 
 */

public class Shirts {

	public static Scanner sc = new Scanner(System.in);

	// Method 1: Prompts user for # of shirts and calculates the total amount to
	// pay.

	public static void main(String[] args) {

		boolean keepRunning = true;

		while (keepRunning = true) {

			try {

				System.out.println("Enter the number of shirts purchased ");

				int shirts = sc.nextInt();

				if (shirts > 3) {

					System.out.println("Total cost: " + (shirts * 10) + "$");

				} else {

					System.out.println("Total cost: " + (shirts * 12) + "$");

				}

				keepRunning = false;

				break;

			} catch (Exception e) {

				System.out.println("Error, restarting...");

				sc.nextLine();

			}

		}

	}
}