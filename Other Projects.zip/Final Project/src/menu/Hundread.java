package menu;

/**

*

* This class displays if you got a good grade or not.

*

* @author Mauricio

* @verison 1.00

* @since 11/13/2015

*/

import java.util.Scanner;

import java.io.IOException;

public class Hundread {

	public static Scanner sc = new Scanner(System.in);

	// Method 1: Prompts user for grades and displays result

	public static void main(String[] args) throws IOException {

		boolean keepRunning = true;

		while (keepRunning = true) {

			try {

				System.out.println("How much did you get in your last quiz?");

				double grade = sc.nextDouble();

				if (grade == 100) {

					System.out.println("Congratulations!");

				} else if (grade > 100 || grade < 0) {

					System.out.println("Not a valid number.");

				} else {

					System.out.println("Do your best next time!");

				}

				keepRunning = false;

				break;

			} catch (Exception e) {

				System.out.println("Error, restarting..");

				sc.nextLine();

			}

		}

	}
}