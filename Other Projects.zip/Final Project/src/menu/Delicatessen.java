package menu;

import java.util.Scanner;

/**
 *
 * 
 * 
 * This class displays the items to be purchased and the total amount to pay.
 *
 * 
 * 
 * @author Mauricio Na�ez and Olivia G�mez
 * 
 * @since 24/11/2015
 * 
 * @version 1.0
 * 
 */

public class Delicatessen {

	public static Scanner sc = new Scanner(System.in);

	// Method 1: Displays items, price and total amount to be payed.

	public static void main(String[] args) {

		boolean keepRunning = true;

		while (keepRunning = true) {

			System.out.println("Enter the item:");

			try {

				String item = sc.nextLine();

				System.out.println("Enter the price:");

				double price = sc.nextDouble();

				System.out.println("Overnight delivery? (0 = No) (1 = Yes)");

				short input = sc.nextShort();

				double shipping = 0;

				if (price < 10) {

					shipping += 2.00;

				} else {

					shipping += 3.00;

				}

				if (input == 1) {

					System.out.println("Invoice:");

					System.out.println(" " + item + "\t" + price);

					System.out.println(" " + "shipping" + "\t" + (shipping + 5.00));

					System.out.println(" " + "total" + "\t" + (price + shipping + 5.00));

				} else if (input == 0) {

					System.out.println("Invoice:");

					System.out.println(" " + item + "\t" + price);

					System.out.println(" " + "shipping" + "\t" + shipping);

					System.out.println(" " + "total" + "\t" + (price + shipping));

				} else {

					System.out.println("0 or 1!");

				}

				keepRunning = false;

				break;

			} catch (Exception e) {

				System.out.println("Error, restarting...");

				sc.nextLine();

			}

		}

	}

}