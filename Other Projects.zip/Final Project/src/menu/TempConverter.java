package menu;

import java.util.Scanner;

import java.io.IOException;

/**
 *
 * 
 * 
 * This class converts degrees fahrenheit into celsius and viceversa.
 *
 * 
 * 
 * @author Mauricio Na�ez and Olivia G�mez
 * 
 * @since 24/11/2015
 * 
 * @version 1.0
 *
 * 
 * 
 */

public class TempConverter {

	public static Scanner sc = new Scanner(System.in);

	// Method 1: Asks user to choose a program.

	public static void main(String[] args) throws IOException {

		boolean keepRunning = true;
		int value = 0;

		boolean exit = false;

		while (keepRunning = true) {

			while (!exit) {

				System.out.println("Select a program: ");

				System.out.println("1.\tconverttoFah");

				System.out.println("2.\tconverttoCelsius");

				System.out.println("9.\tExit");

				try {

					value = sc.nextInt();

				} catch (Exception e) {

					System.out.print("Invalid input, try again.");

					sc.nextLine();

					value = 0;

				}

				switch (value) {

				case 1:

					converttoFah(value);

					break;

				case 2:

					converttoCelsius(value);
					break;

				case 9:

					System.out.println("Later!");

					exit = true;

					keepRunning = false;

					break;

				}

			}
			keepRunning = false;

			break;
		}

	}

	// Method 2: Prompts the user for a value and converts it to fahrenheit.

	public static void converttoFah(double C) throws IOException {

		boolean keepRunning = true;

		while (keepRunning = true) {

			try {

				System.out.println("Enter a number in celsius");

				C = sc.nextDouble();

				double F = 9 * C / 5 + 32;

				System.out.println(F + " degrees farenheit");

				keepRunning = false;

				break;

			} catch (Exception e) {

				System.out.println("Error");

				sc.nextLine();

			}
		}

	}

	// Method 3: Prompts the user for a value and converts it to celsius.

	public static void converttoCelsius(double F) throws IOException {

		boolean keepRunning = true;

		while (keepRunning = true) {

			try {

				System.out.println("Enter a number in farenheit");

				F = sc.nextDouble();

				double C = 5 * (F - 32) / 9;

				System.out.println(C + " degrees celsius");

				keepRunning = false;

				break;

			} catch (Exception e) {

				System.out.println("Error");

				sc.nextLine();

			}

		}

	}
}