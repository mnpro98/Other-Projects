package menu;

/**

*

* This class creates a christmas tree.

*

* @author Mauricio

* @version 1.00

* @since 11/19/2015

*/

import java.util.Scanner;

public class BytePrint {

	public static Scanner sc = new Scanner(System.in);

	// Mehtod 1: Determines if interger is smaller than 50.

	public static void main(String[] args) {

		boolean keepRunning = true;

		while (keepRunning = true) {

			int a = 70;

			while (a >= 50)

				a = 30;

			System.out.println("Insert a positive integer lesser than 50");
			try{

			int height = sc.nextInt();

			for (int i = 0; i < height; i++) {

				for (int j = 0; j < height; j++) {

					if (i + j >= height - 1) {

						System.out.print("*");

					} else {

						System.out.print(" ");

					}

				}

				System.out.println();

			}

			System.out.println("Want to try again? (s = Yes) (n = No)");

			String d = sc.next();

			if (d.contains("s")) {

				a = 70;
			}else{
				break;
			}


		}catch(Exception e){
			sc.nextLine();
		}

	}
}
}